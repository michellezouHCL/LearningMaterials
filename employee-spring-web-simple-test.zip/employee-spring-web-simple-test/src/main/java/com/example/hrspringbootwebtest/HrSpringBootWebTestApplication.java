package com.example.hrspringbootwebtest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HrSpringBootWebTestApplication {

	public static void main(String[] args) {
		SpringApplication.run(HrSpringBootWebTestApplication.class, args);
	}

}
