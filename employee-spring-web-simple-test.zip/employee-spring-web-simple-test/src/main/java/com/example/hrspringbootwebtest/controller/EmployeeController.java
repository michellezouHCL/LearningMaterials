package com.example.hrspringbootwebtest.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.function.EntityResponse;

import com.example.hrspringbootwebtest.model.Employee;
import com.example.hrspringbootwebtest.repository.EmployeeRepository;

@RestController
public class EmployeeController {
	@Autowired
	private EmployeeRepository employeeRepository;

	@GetMapping("/employees")
	public List<Employee> getAllEmployees() {
		return employeeRepository.findAll();
	}

	@PostMapping("/employees")
	public Employee createEmployees(@Validated @RequestBody final Employee employee) {
		return employeeRepository.save(employee);
	}

	@GetMapping("/employees/{id}")
	public ResponseEntity<Employee> getEmployeeById(@PathVariable(value = "id") final Long employeeId) {
		
		Optional<Employee> employee = employeeRepository.findById(employeeId);
		if (employee.isPresent()) {
			return new ResponseEntity<>(employee.get(), HttpStatus.OK);
		} else {
			throw new IllegalArgumentException();
		}
		//return ResponseEntity.ok(employeeRepository.findById(employeeId).get());
		/*Employee employee = employeeRepository.findById(employeeId)
		           .orElseThrow(() -> new IllegalArgumentException("Employee not found for this id :: " + employeeId));
		        return ResponseEntity.ok().body(employee);*/
	}

	@PutMapping("/employees/{id}")
	public Employee updateEmployee(@PathVariable(value = "id") Long employeeId,
			@Validated @RequestBody Employee employeeDetails) {

		return employeeRepository.findById(employeeId).map(employee -> {
			employee.setEmail(employeeDetails.getEmail());
			employee.setFirstName(employeeDetails.getFirstName());
			employee.setLastName(employeeDetails.getLastName());
			return employeeRepository.save(employee);
		}).orElseGet(() -> {
			employeeDetails.setEmployeeId(employeeId);
			return employeeRepository.save(employeeDetails);
		});
	}

	@DeleteMapping("/employees/{id}")
	public ResponseEntity<?> deleteEmployee(@PathVariable(value = "id") Long employeeId) {

		employeeRepository.deleteById(employeeId);
		return new ResponseEntity<>(employeeId, HttpStatus.ACCEPTED);
	}
}
