package scrap;

public class FoodFactory {
    // any member and/or class variables here?
   private static FoodFactory foodFactory = new FoodFactory();
    static FoodFactory getFactory() {
       // add code here
        return foodFactory;
    }
    
    java.util.Map<String, Cuisine> cuisines = new java.util.HashMap<String, Cuisine>();
    
    void registerCuisine(String cuisineKey, Cuisine cuisine ) {
         // add code here
         cuisines.put(cuisineKey, cuisine);
    }
    
    public Cuisine serveCuisine(String cuisineKey, String dish) throws UnservableCuisineRequestException{
        // add code here
        if(!cuisines.containsKey(cuisineKey)){
            throw new UnservableCuisineRequestException("Unservable cuisine "+ cuisineKey + "for dish "+ dish);
        } else{
            return cuisines.get(cuisineKey).serveFood(dish);
        }
    }
} 
