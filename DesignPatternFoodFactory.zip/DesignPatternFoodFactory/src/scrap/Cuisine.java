package scrap;

public abstract class Cuisine {
	public abstract Cuisine serveFood(String dish);
}
