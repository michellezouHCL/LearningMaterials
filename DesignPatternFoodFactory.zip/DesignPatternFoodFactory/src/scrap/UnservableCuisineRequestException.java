package scrap;

public class UnservableCuisineRequestException extends Exception {
	public UnservableCuisineRequestException(String message) {
        super(message);
    }
}
