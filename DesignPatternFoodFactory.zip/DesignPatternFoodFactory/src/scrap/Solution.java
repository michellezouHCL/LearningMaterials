package scrap;
import java.util.Scanner;

public class Solution {
    private static final Scanner INPUT_READER = new Scanner(System.in);
    private static final FoodFactory FOOD_FACTORY = FoodFactory.getFactory();
    
    
    /* What is a static block and when is it accessed on program execution?
       Looks like registerCuisine(String, <some class>) will have some behavior you must code. 
       Will the second parameter be a class? If so, what behaviors/methods, member variables should they contain?
       How will this method work with the static block and does this help you more on
       the purpose and function of the static block?
    */
    static {
        FoodFactory.getFactory().registerCuisine("Chinese", new Chinese());
        FoodFactory.getFactory().registerCuisine("Italian", new Italian());
        FoodFactory.getFactory().registerCuisine("Japanese", new Japanese());
        FoodFactory.getFactory().registerCuisine("Mexican", new Mexican());
    }
    
    public static void main(String[] args) {
        int totalNumberOfOrders = Integer.parseInt(INPUT_READER.nextLine());
        while (totalNumberOfOrders-- > 0) {
            String[] food = INPUT_READER.nextLine().split(" ");
            String cuisine = food[0];
            String dish = food[1];

            try {
                /* What makes the if statement conditional true? When are two objects equal? 
                   How can you code your getFactory() method to make this work?
                   Otherwise the if block is false and you will not get any output.
                   What design pattern if any will be used to achieve this goal?
                */
                if (FOOD_FACTORY.equals(FoodFactory.getFactory())) {
                    Cuisine servedFood = FOOD_FACTORY.serveCuisine(cuisine, dish);
                     /* Note servedFood is downcast to the food type. Does this tell you what classes you may have 
                       to add and what methods and member variables you may need in the added classes?
                       Will there be even more classes you may want to add or need to add?
                       What design pattern(s) is/are demonstrated here?
                       What about SOLID principles of design? Remember method serveFood(String) 
                       is abstract in abstract class Cuisine.
                    */

                    switch (cuisine) {
                        case "Chinese":
                            Chinese chineseDish = (Chinese) servedFood;
                            System.out.println("Serving " + chineseDish.getDish() + "(Chinese)");
                            break;
                        case "Italian":
                            Italian italianDish = (Italian) servedFood;
                            System.out.println("Serving " + italianDish.getDish() + "(Italian)");
                            break;
                        case "Japanese":
                            Japanese japaneseDish = (Japanese) servedFood;
                            System.out.println("Serving " + japaneseDish.getDish() + "(Japanese)");
                            break;
                        case "Mexican":
                            Mexican mexicanDish = (Mexican) servedFood;
                            System.out.println("Serving " + mexicanDish.getDish() + "(Mexican)");
                            break;
                        default:
                            break;
                    }
                }
                // Read problem statement to find where you throw this exception. Remember the exception code is locked and can't be changed.
            } catch (UnservableCuisineRequestException ex) {
                System.out.println(ex.getMessage());
            }
        }
    }
}
