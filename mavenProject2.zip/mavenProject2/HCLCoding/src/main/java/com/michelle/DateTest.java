package com.michelle;

public class DateTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Date newYear = new Date(1,1,2021);
		newYear.displayDate(newYear.getMonth(), newYear.getDay(), newYear.getYear());
	}

}
