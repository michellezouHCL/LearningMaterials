package com.michelle;

class Cycle {
	String define_me() {
		return "a vehicle with pedals.";
	}
}