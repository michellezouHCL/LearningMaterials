package com.michelle;

public class InheritenceExample {
    public static void main(String []args){
        Bike M = new Bike();
        System.out.println(M.define_me());
    }
}
