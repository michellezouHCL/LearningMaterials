package com.michelle;

public class PersonTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Person p1 = new Person("John", 23, 10);
		p1.startWalking();
	}

}
