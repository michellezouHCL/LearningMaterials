package com.hcl;

import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.*;

@WebServlet("/jquery")
public class JQueryServlet extends HttpServlet {
	
	public void doGet(HttpServletRequest req,HttpServletResponse res) throws ServletException,IOException{
		res.setContentType("text/html");
		
		String name="Welcome "+req.getParameter("user");
		if(req.getParameter("user").toString().equals("")){
			name="Hello user";
		}
		PrintWriter pw=res.getWriter();
		pw.println(name);
		
		
	}

}
