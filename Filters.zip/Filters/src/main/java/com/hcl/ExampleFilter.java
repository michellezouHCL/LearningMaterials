package com.hcl;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ExampleFilter implements Filter {

	// init method is invoked only once. used to initialize the filter
	public void init(FilterConfig filterConfig) throws ServletException {
		// TODO Auto-generated method stub
		
	}

	
	// doFilter method is invoked every time when user request to any resource, to
	// which the filter is mapped. use to perform filter task
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
			throws IOException, ServletException {
		// TODO Auto-generated method stub
		PrintWriter pw = response.getWriter();
		pw.println("Welcome to the world of filter  b4");
		chain.doFilter(request, response);
		pw.println("Welcome to the world of filter  after");
	}

	// destroy method will invoke only once when filter is taken out of service
	public void destroy() {
		// TODO Auto-generated method stub

	}


	

}
