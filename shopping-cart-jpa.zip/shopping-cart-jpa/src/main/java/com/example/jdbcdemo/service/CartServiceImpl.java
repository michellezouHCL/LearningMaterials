package com.example.jdbcdemo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.jdbcdemo.model.Cart;
import com.example.jdbcdemo.repository.CartRepository;

@Service
public class CartServiceImpl implements CartService{
	@Autowired
	CartRepository cr;
	public void create(Cart cart) {
		cr.save(cart);
	}

	public Cart getById(Long id) {
		return cr.findById(id).orElse(null);
	}

	public void update(Cart e) {
		cr.save(e);
	}

	public void deleteById(long l) {
		cr.deleteById(l);
	}
}
